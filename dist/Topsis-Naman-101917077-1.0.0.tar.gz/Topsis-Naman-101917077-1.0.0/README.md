---
# Topsis Score Generator
### By Naman Aggarwal
---
&nbsp;
##### "Topsis-Naman-101917077":
###### A package for calculating topsis score.  
&nbsp;

### License:

MIT